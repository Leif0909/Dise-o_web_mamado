# 📄 script.js — El Cerebro de la Pokédex

## ¿Qué hace este archivo?
Contiene **toda la lógica** del programa. Se comunica con internet, guarda datos, y actualiza lo que se ve en pantalla. Es el archivo más importante y el más largo.

---

## PARTE 1: Datos que no cambian (Constantes)

### Colores por tipo de Pokémon
```javascript
const TIPO_COLORES = {
  normal: '#A8A77A', fire: '#EE8130', water: '#6390F0', ...
};
```
> Es como un diccionario de colores. Cuando el código quiere pintar la etiqueta del tipo "fuego", busca aquí y obtiene el color naranja `#EE8130`.

---

### Datos de las generaciones
```javascript
const GENERACIONES = {
  '1': { nombre: 'Gen I (Kanto)', offset: 0, limit: 151, inicio: 1, fin: 151 },
  '2': { nombre: 'Gen II (Johto)', offset: 151, limit: 100, inicio: 152, fin: 251 },
  ...
};
```
> Guarda cuántos Pokémon hay en cada generación y en qué número empiezan y terminan. Sirve para los filtros del catálogo.

---

## PARTE 2: Variables de Estado

```javascript
let pokemonActual  = null;  // El Pokémon que se muestra en pantalla ahora mismo
let equipo         = [];    // Lista de Pokémon del equipo del usuario
let offsetCatalogo = 0;     // En qué Pokémon empieza la página actual
let filtroTipo     = '';    // Qué tipo está seleccionado en el filtro
let filtroGen      = '';    // Qué generación está seleccionada
```
> Estas son como variables de un videojuego que guardan "qué está pasando ahora". Por ejemplo, `equipo` es como la mochila del entrenador.

---

## PARTE 3: Sesión del usuario

### Verificar si el usuario está logueado
```javascript
function iniciarSesionUsuario() {
  if (!NOMBRE_USUARIO) {
    window.location.href = 'index.html'; // Regresa al login si no hay nombre
    return;
  }
  mensajeUsuario.textContent = `Hola, ${NOMBRE_USUARIO} 👋`;
}
```
> Al abrir la app, lo primero que hace es revisar si hay un nombre guardado. Si no hay, te manda de regreso a la pantalla de login.

### Cerrar sesión
```javascript
function cerrarSesion() {
  localStorage.removeItem('pokemonUser'); // Borra el nombre guardado
  window.location.href = 'index.html';   // Regresa al login
}
```
> Borra el nombre de la memoria del navegador y te regresa al inicio. Como cerrar sesión en cualquier app.

---

## PARTE 4: Modo Oscuro / Claro

```javascript
function alternarTema() {
  const esDark = document.body.classList.toggle('dark-mode');
  localStorage.setItem('darkMode', String(esDark)); // Guarda preferencia
  themeToggle.textContent = esDark ? '☀️ Claro' : '🌙 Oscuro';
}
```
> Cuando presionas el botón de tema:
> 1. Agrega o quita la clase `dark-mode` al body (que cambia los colores con CSS).
> 2. Guarda tu preferencia para que la recuerde la próxima vez.

---

## PARTE 5: El Equipo del Entrenador

### Cargar equipo desde la memoria
```javascript
function cargarEquipo() {
  equipo = JSON.parse(localStorage.getItem(CLAVE_EQUIPO)) || [];
  renderizarEquipo();
}
```
> Al iniciar la app, lee el equipo guardado en la memoria del navegador. Si no hay nada, empieza con una lista vacía `[]`.

### Mostrar el equipo en pantalla
```javascript
function renderizarEquipo(lista = equipo) {
  equipoLista.innerHTML = ''; // Borra lo que había antes
  lista.forEach((pokemon, index) => {
    // Crea un elemento de lista por cada Pokémon
    const li = document.createElement('li');
    li.innerHTML = `
      <img src="${pokemon.imagen}" alt="${pokemon.nombre}" />
      <span>${pokemon.nombre}</span>
      <button class="team-remove-button">✕</button>
    `;
    equipoLista.appendChild(li);
  });
}
```
> Dibuja la lista del equipo. Por cada Pokémon crea un elemento visual con su imagen, nombre y un botón para quitarlo.

### Agregar Pokémon al equipo
```javascript
function agregarAlEquipo() {
  if (equipo.length >= 6) {
    alert('Tu equipo ya tiene 6 Pokémon (el máximo).');
    return;
  }
  if (equipo.some(p => p.id === pokemonActual.id)) {
    alert('Este Pokémon ya está en tu equipo.');
    return;
  }
  equipo.push(pokemonActual); // Agrega al final de la lista
  guardarEquipo();
}
```
> Revisa 3 cosas antes de agregar:
> 1. ¿Ya buscaste un Pokémon?
> 2. ¿Ya tienes 6 en el equipo (el máximo)?
> 3. ¿Ya está ese Pokémon en el equipo?
> Si todo está bien, lo agrega.

### Quitar Pokémon del equipo
```javascript
equipo.splice(indexReal, 1); // Elimina 1 elemento en esa posición
guardarEquipo();
```
> `splice()` es como sacar una carta de un mazo: elimina el elemento en esa posición y cierra el espacio.

---

## PARTE 6: Búsqueda de Pokémon (La más importante)

```javascript
async function buscarPokemon(query) {
  const respuesta = await fetch(`https://pokeapi.co/api/v2/pokemon/${query}`);

  if (!respuesta.ok) throw new Error(`Pokémon "${query}" no encontrado.`);

  const datos = await respuesta.json();

  const pokemon = {
    id:          datos.id,
    nombre:      datos.name,
    imagen:      datos.sprites.other['official-artwork'].front_default,
    tipos:       datos.types.map(t => t.type.name),
    altura:      datos.height,
    peso:        datos.weight,
    habilidades: datos.abilities.map(a => a.ability.name),
  };

  mostrarTarjetaPokemon(pokemon);
}
```

> ### Palabras clave importantes:
> - **`async`** → Esta función puede "esperar" sin congelar toda la página.
> - **`await`** → "Para aquí y espera la respuesta de internet antes de continuar."
> - **`fetch()`** → Le manda una petición a la PokéAPI (una página web con datos de Pokémon).
> - **`response.json()`** → Convierte la respuesta en datos que JavaScript puede leer.
>
> Después de obtener los datos, saca solo lo que necesita (imagen, tipos, peso, etc.) y lo muestra en la tarjeta.

---

## PARTE 7: Catálogo

### Cargar 50 Pokémon
```javascript
async function cargarCatalogo(offset = 0) {
  const res = await fetch(`https://pokeapi.co/api/v2/pokemon?offset=${offset}&limit=50`);
  const data = await res.json();
  renderizarCatalogo(data.results);
}
```
> Pide a la API una lista de 50 Pokémon empezando desde el número `offset`. Si `offset=0`, empieza desde Bulbasaur. Si `offset=50`, empieza desde el Pokémon #51.

### Filtrar por tipo
```javascript
async function filtrarPorTipo(tipo) {
  const res = await fetch(`https://pokeapi.co/api/v2/type/${tipo}`);
  const data = await res.json();
  const lista = data.pokemon.slice(0, 50).map(p => p.pokemon);
  renderizarCatalogo(lista);
}
```
> Le pregunta a la API: "Dame todos los Pokémon de tipo fuego". Luego toma los primeros 50 y los muestra.

### Filtrar por generación
```javascript
async function filtrarPorGeneracion(gen) {
  const generacion = GENERACIONES[gen]; // Busca los datos de esa gen en nuestra constante
  const res = await fetch(`https://pokeapi.co/api/v2/pokemon?offset=${generacion.offset}&limit=${generacion.limit}`);
  renderizarCatalogo(data.results);
}
```
> Usa el `offset` y `limit` de la generación para pedirle a la API exactamente los Pokémon de esa región.

---

## PARTE 8: Movimientos e Ítems

```javascript
async function buscarMovimiento(termino) {
  const res = await fetch(`https://pokeapi.co/api/v2/move/${termino}`);
  const data = await res.json();
  // Muestra: nombre, PP, poder, precisión
}

async function buscarItem(termino) {
  const res = await fetch(`https://pokeapi.co/api/v2/item/${termino}`);
  const data = await res.json();
  // Muestra: imagen del ítem y descripción en español
}
```
> Funcionan igual que la búsqueda de Pokémon, pero cambian la dirección de la API para buscar en la sección de movimientos o de ítems.

---

## PARTE 9: Función de Inicio (La que arranca todo)

```javascript
function init() {
  iniciarSesionUsuario(); // 1. Verifica si hay sesión activa
  aplicarTema();          // 2. Aplica modo oscuro o claro
  cargarEquipo();         // 3. Carga el equipo guardado
  configurarTabs();       // 4. Activa las pestañas
  configurarEventos();    // 5. Conecta los botones con sus acciones
  cargarCatalogo(0);      // 6. Muestra los primeros 50 Pokémon
}

init(); // ← Esta línea ejecuta todo al cargar la página
```
> `init()` es como el botón de encendido de la app. Ejecuta todo lo necesario en orden cuando la página carga.

---

## Resumen general del script.js

| Función | ¿Qué hace? |
|---------|------------|
| `iniciarSesionUsuario()` | Verifica que el usuario haya iniciado sesión |
| `cerrarSesion()` | Borra sesión y regresa al login |
| `alternarTema()` | Cambia entre modo oscuro y claro |
| `cargarEquipo()` | Lee el equipo desde la memoria del navegador |
| `renderizarEquipo()` | Dibuja el equipo en pantalla |
| `agregarAlEquipo()` | Agrega el Pokémon actual al equipo |
| `buscarPokemon()` | Pide datos a la PokeAPI y los muestra |
| `cargarCatalogo()` | Carga 50 Pokémon del catálogo |
| `filtrarPorTipo()` | Filtra el catálogo por tipo |
| `filtrarPorGeneracion()` | Filtra el catálogo por generación |
| `buscarMovimiento()` | Busca datos de un movimiento en la API |
| `buscarItem()` | Busca datos de un ítem en la API |
| `init()` | Arranca toda la aplicación |
