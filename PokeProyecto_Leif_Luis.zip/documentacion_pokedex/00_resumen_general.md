# 🗺️ Resumen General — Proyecto Pokédex (Leif & Luis)

## ¿Qué es este proyecto?
Una **Pokédex web** hecha con HTML, CSS y JavaScript puro (sin frameworks). Se conecta a la [PokéAPI](https://pokeapi.co/) para obtener datos reales de los Pokémon.

---

## Estructura de archivos

```
pokeProyecto/
│
├── index.html     → Pantalla de inicio de sesión (login)
├── index2.html    → App principal con las 4 pestañas
├── script.js      → Toda la lógica en JavaScript
└── styles.css     → Todo el diseño visual
```

---

## ¿Cómo fluye la app? (Paso a paso)

```
1. Usuario abre index.html
        ↓
2. Escribe su nombre y presiona "Entrar"
        ↓
3. El nombre se guarda en localStorage (memoria del navegador)
        ↓
4. La app redirige a index2.html
        ↓
5. script.js arranca (función init()):
   ├── Verifica que haya nombre guardado
   ├── Aplica el tema (oscuro/claro)
   ├── Carga el equipo guardado
   └── Carga los primeros 50 Pokémon del catálogo
        ↓
6. Usuario navega por las pestañas:
   ├── Buscar → Escribe nombre/número → script.js llama a PokéAPI → muestra tarjeta
   ├── Equipo → Ve sus Pokémon guardados → puede filtrar o quitar
   ├── Movimientos → Escribe nombre en inglés → muestra PP, poder, precisión
   └── Ítems → Escribe nombre en inglés → muestra imagen y descripción
```

---

## Tecnologías usadas

| Tecnología | ¿Para qué se usa? |
|------------|-------------------|
| **HTML** | Estructura y contenido de la página |
| **CSS** | Colores, tamaños, animaciones y diseño |
| **JavaScript** | Lógica, conexión a la API, interactividad |
| **localStorage** | Guardar el nombre del usuario y el equipo en el navegador |
| **PokéAPI** | Base de datos gratuita con info de todos los Pokémon |
| **fetch / async/await** | Para pedir datos a internet sin congelar la página |

---

## Conceptos clave del proyecto

### 🔑 localStorage
Es como una pequeña memoria del navegador donde la app guarda datos aunque se cierre la pestaña. Se usa para:
- Guardar el nombre del usuario (`pokemonUser`)
- Guardar el equipo (`pokemonTeam`)
- Recordar si prefieres modo oscuro (`darkMode`)

### 🌐 API (PokéAPI)
Una "API" es como un menú de restaurante que le ofreces a otros programas. La PokéAPI tiene datos de todos los Pokémon. Cuando el código hace `fetch('https://pokeapi.co/...')`, es como hacer un pedido al mesero y esperar la comida.

### ⚡ async / await
Pedir datos a internet tarda tiempo. `async/await` permite decirle al código "espera aquí hasta que lleguen los datos" sin que toda la página se congele mientras espera.

### 🏗️ DOM (Document Object Model)
Es la forma en que JavaScript puede cambiar lo que se ve en pantalla. Cuando el código dice `document.getElementById('pokemon-name').textContent = 'Pikachu'`, está modificando directamente el texto que aparece en la página.

---

## Funcionalidades del proyecto

- ✅ Inicio de sesión con nombre de usuario
- ✅ Modo oscuro / claro con memoria de preferencia
- ✅ Búsqueda de Pokémon por nombre o número
- ✅ Catálogo de 50 Pokémon con paginación
- ✅ Filtros del catálogo por generación y por tipo
- ✅ Equipo de hasta 6 Pokémon con filtros
- ✅ Búsqueda de movimientos con estadísticas
- ✅ Búsqueda de ítems con descripción en español
- ✅ Cierre de sesión

---

## Documentos de este paquete

1. `01_index_login.md` → Login (primera pantalla)
2. `02_index2_app.md` → App principal (HTML)
3. `03_script_js.md` → La lógica completa (JavaScript)
4. `04_styles_css.md` → El diseño visual (CSS)
5. `00_resumen_general.md` → Este archivo (visión general)
