# 📄 styles.css — El Diseño Visual de la Pokédex

## ¿Qué hace este archivo?
Le da **color, forma y estilo** a toda la aplicación. Sin este archivo, todo se vería como texto negro sobre fondo blanco sin formato.

---

## Partes importantes

### 1. Variables de colores (raíz global)
```css
:root {
  --color-rojo:     #dc2626;
  --color-fondo:    #f1f5f9;
  --color-tarjeta:  #ffffff;
  --color-texto:    #1e293b;
  --color-borde:    #e2e8f0;
}
```
> `:root` es como una lista de ingredientes al inicio de una receta. En lugar de escribir `#dc2626` (rojo) en cada lugar que se necesite, se usa `var(--color-rojo)`. Si quieres cambiar el rojo de toda la app, solo cambias un número aquí.

---

### 2. Modo oscuro
```css
body.dark-mode {
  --color-fondo:   #0f172a;
  --color-tarjeta: #1e293b;
  --color-texto:   #f1f5f9;
}
```
> Cuando JavaScript agrega la clase `dark-mode` al body, estas líneas sobreescriben los colores anteriores. Es como cambiar el "tema" de colores con solo agregar una palabra.

---

### 3. El header (barra de arriba)
```css
header {
  background: var(--color-rojo);
  color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem 1.5rem;
}
```
> El encabezado rojo de la Pokédex. `display: flex` pone los elementos en línea horizontal. `justify-content: space-between` los separa al máximo (uno a la izquierda, otro a la derecha).

---

### 4. Las pestañas de navegación
```css
.tab-button {
  border: none;
  background: transparent;
  cursor: pointer;
  padding: 0.75rem 1rem;
}

.tab-button.active {
  border-bottom: 3px solid var(--color-rojo);
  color: var(--color-rojo);
  font-weight: 700;
}
```
> Los botones de pestaña son transparentes por defecto. Cuando tienen la clase `active` (que JavaScript agrega al hacer clic), les aparece una línea roja abajo y el texto se pone en negritas y rojo.

---

### 5. Las tarjetas (cards)
```css
.card {
  background: var(--color-tarjeta);
  border-radius: 1rem;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,.08);
  margin-bottom: 1rem;
}
```
> Las "tarjetas" son los contenedores blancos con bordes redondeados que se ven en toda la app. `border-radius` redondea las esquinas. `box-shadow` agrega una sombra suave para que parezcan "levantadas".

---

### 6. El catálogo de Pokémon (cuadrícula)
```css
#catalogue-list {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 0.75rem;
}
```
> Organiza los Pokémon en una cuadrícula de 5 columnas. `1fr` significa "1 fracción del espacio disponible", lo que hace que todas las columnas tengan el mismo ancho automáticamente.

---

### 7. Las etiquetas de tipo (badges de colores)
```css
.tag {
  display: inline-block;
  border-radius: 999px;
  padding: 0.2rem 0.7rem;
  font-size: 0.75rem;
  color: #fff;
  font-weight: 600;
}
```
> Las pastillitas de colores que muestran el tipo del Pokémon (fuego, agua, etc.). El `border-radius: 999px` las hace completamente ovaladas (como una píldora).

---

### 8. La pokébola decorativa
```css
.pokeball-deco {
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 50%;
  background: conic-gradient(white 0deg 180deg, red 180deg 360deg);
  border: 3px solid white;
}
```
> ¡Sin imágenes! La pokébola se dibuja solo con CSS usando un gradiente circular (`conic-gradient`) que pinta la mitad de blanco y la mitad de rojo.

---

### 9. Animaciones
```css
.catalogue-item:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 16px rgba(0,0,0,.12);
}
```
> Cuando el mouse pasa sobre un Pokémon del catálogo, sube 4 píxeles y su sombra se hace más grande. Crea la sensación de que el elemento "flota" al pasar el mouse.

---

### 10. Clases de utilidad importantes

| Clase | ¿Qué hace? |
|-------|-----------|
| `.hidden` | Oculta un elemento completamente (`display: none`) |
| `.loading-msg` | Estilo para el texto "Cargando..." |
| `.cat-empty` | Estilo para el mensaje "No se encontraron Pokémon" |
| `.dark-mode` | Activa el tema oscuro en toda la app |
| `.active` | Marca una pestaña o panel como el visible actualmente |

---

## Resumen en una frase
> El CSS define **cómo se ve** todo: colores, tamaños, posiciones y animaciones. JavaScript cambia las clases de los elementos y el CSS hace el resto automáticamente.
