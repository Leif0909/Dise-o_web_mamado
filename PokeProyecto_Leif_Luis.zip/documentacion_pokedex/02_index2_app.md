# 📄 index2.html — La App Principal (Pokédex)

## ¿Qué hace este archivo?
Es la **pantalla principal** de la Pokédex. Tiene 4 secciones (pestañas) a las que el usuario puede cambiar:

| Pestaña | ¿Qué hace? |
|--------|------------|
| 🔍 Buscar | Busca un Pokémon por nombre o número |
| 👥 Equipo | Muestra los Pokémon guardados en tu equipo |
| ⚡ Movimientos | Busca información de ataques |
| 🎒 Ítems | Busca información de objetos del juego |

---

## Partes importantes del código

### 1. El encabezado (Header)
```html
<header>
  <h1>Pokédex</h1>
  <span id="header-user">Usuario</span>
  <button id="theme-toggle">🌙 Oscuro</button>
  <button id="logout-button">Salir</button>
</header>
```
> La barra de arriba muestra el nombre del usuario, un botón para cambiar entre modo oscuro/claro, y un botón para cerrar sesión.

---

### 2. Las pestañas de navegación
```html
<nav class="tab-nav">
  <button class="tab-button active" data-tab="search">Buscar</button>
  <button class="tab-button" data-tab="usuario">Equipo</button>
  <button class="tab-button" data-tab="movimientos">Movimientos</button>
  <button class="tab-button" data-tab="items">Ítems</button>
</nav>
```
> Son como las pestañas de un cuaderno. Solo se ve una sección a la vez. El `data-tab` es una etiqueta que le dice al código JavaScript qué panel mostrar cuando se hace clic.

---

### 3. La tarjeta del Pokémon encontrado
```html
<div class="card hidden" id="pokemon-card">
  <img id="pokemon-image" />
  <h2 id="pokemon-name">—</h2>
  <p id="pokemon-id">—</p>
  <div id="pokemon-types"></div>
  <button id="add-team-button">Agregar al equipo</button>
</div>
```
> Esta tarjeta está **escondida al inicio** (por la clase `hidden`). Solo aparece cuando el usuario busca un Pokémon. Muestra la imagen, nombre, número, tipos y un botón para guardarlo en el equipo.

---

### 4. El catálogo con filtros
```html
<select id="filter-gen">
  <option value="1">Gen I — Kanto (1–151)</option>
  ...
</select>
<select id="filter-type">
  <option value="fire">Fuego</option>
  ...
</select>
<div id="catalogue-list"></div>
```
> Los menús desplegables (select) permiten filtrar los Pokémon por generación o por tipo. La cuadrícula `catalogue-list` es donde aparecen las fotos de los Pokémon.

---

### 5. La paginación del catálogo
```html
<button id="catalogue-prev">← Anterior</button>
<button id="catalogue-next">Siguiente →</button>
```
> Como los Pokémon son muchos, se muestran de 50 en 50. Estos botones permiten pasar de página.

---

### 6. El buscador de movimientos e ítems
```html
<!-- Movimientos -->
<input id="move-search-input" placeholder="Nombre del movimiento" />

<!-- Ítems -->
<input id="item-input" placeholder="Nombre del ítem" />
```
> Ambas pestañas piden el nombre **en inglés** porque así los tiene guardados la PokéAPI.

---

## Resumen en una frase
> Este archivo es el **cuerpo de la app**: contiene todo el diseño visual y los contenedores donde JavaScript va a poner la información de los Pokémon.
