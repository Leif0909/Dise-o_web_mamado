# 📄 index.html — La Pantalla de Inicio de Sesión

## ¿Qué hace este archivo?
Es la **primera pantalla** que ve el usuario. Aquí el entrenador escribe su nombre para entrar a la Pokédex.

---

## Partes importantes del código

### 1. El formulario de nombre
```html
<form id="login-form">
  <input id="login-input" type="text" placeholder="Nombre de entrenador" maxlength="30" />
  <button type="submit">Entrar</button>
</form>
```
> Esto es como una caja donde el usuario escribe su nombre y presiona un botón para entrar. El `maxlength="30"` significa que no puede escribir más de 30 letras.

---

### 2. Revisar si ya hay sesión activa
```javascript
if (localStorage.getItem('pokemonUser')) {
  window.location.href = 'index2.html';
}
```
> Imagina que el navegador tiene una memoria pequeña (como una libretita). Si ya guardó el nombre del usuario antes, lo manda directo a la app sin pedirle que escriba su nombre otra vez. Es como cuando entras a una app y ya tienes la sesión abierta.

---

### 3. Guardar el nombre y entrar
```javascript
loginForm.addEventListener('submit', function(e) {
  e.preventDefault(); // Evita que la página se recargue
  const nombre = loginInput.value.trim(); // Lee lo que escribió el usuario
  if (!nombre) {
    loginMsg.textContent = '⚠ Escribe tu nombre para continuar.';
    return; // Para aquí si el campo está vacío
  }
  localStorage.setItem('pokemonUser', nombre); // Guarda el nombre en la memoria del navegador
  window.location.href = 'index2.html'; // Manda al usuario a la app principal
});
```
> Cuando el usuario presiona "Entrar":
> 1. Se revisa que no haya dejado el campo vacío.
> 2. Si escribió algo, se guarda su nombre en la memoria del navegador.
> 3. Lo lleva a la pantalla principal (index2.html).

---

## Resumen en una frase
> Este archivo es la **puerta de entrada**: pide el nombre del entrenador, lo guarda, y abre la Pokédex.
