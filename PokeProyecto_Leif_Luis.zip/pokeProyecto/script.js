
const TIPO_COLORES = {
  normal:   '#A8A77A', fire:     '#EE8130', water:    '#6390F0',
  electric: '#F7D02C', grass:    '#7AC74C', ice:      '#96D9D6',
  fighting: '#C22E28', poison:   '#A33EA1', ground:   '#E2BF65',
  flying:   '#A98FF3', psychic:  '#F95587', bug:      '#A6B91A',
  rock:     '#B6A136', ghost:    '#735797', dragon:   '#6F35FC',
  dark:     '#705746', steel:    '#B7B7CE', fairy:    '#D685AD',
};


//   offset → cuántos Pokémon hay antes de esta generación
//   limit  → cuántos Pokémon tiene esta generación
//   inicio / fin → rango de IDs para filtrar el equipo
const GENERACIONES = {
  '1': { nombre: 'Gen I (Kanto)',      offset: 0,    limit: 151, inicio: 1,   fin: 151  },
  '2': { nombre: 'Gen II (Johto)',     offset: 151,  limit: 100, inicio: 152, fin: 251  },
  '3': { nombre: 'Gen III (Hoenn)',    offset: 251,  limit: 135, inicio: 252, fin: 386  },
  '4': { nombre: 'Gen IV (Sinnoh)',    offset: 386,  limit: 107, inicio: 387, fin: 493  },
  '5': { nombre: 'Gen V (Unova)',      offset: 493,  limit: 156, inicio: 494, fin: 649  },
  '6': { nombre: 'Gen VI (Kalos)',     offset: 649,  limit: 72,  inicio: 650, fin: 721  },
  '7': { nombre: 'Gen VII (Alola)',    offset: 721,  limit: 88,  inicio: 722, fin: 809  },
  '8': { nombre: 'Gen VIII (Galar)',   offset: 809,  limit: 96,  inicio: 810, fin: 905  },
};


// ============================================================
// SECCIÓN 3: VARIABLES DE ESTADO
// ============================================================
// Estas variables guardan el "estado" de la aplicación,
// es decir, qué está pasando en este momento.

const NOMBRE_USUARIO = localStorage.getItem('pokemonUser'); // Nombre del usuario guardado
const CLAVE_EQUIPO   = 'pokemonTeam';                       // Nombre de la clave en localStorage
const LIMITE         = 50;                                   // Pokémon por página del catálogo

let pokemonActual  = null;  // El Pokémon que se está mostrando en la tarjeta de búsqueda
let equipo         = [];    // Arreglo con los Pokémon del equipo del usuario
let offsetCatalogo = 0;     // Posición de inicio de la página actual del catálogo
let filtroTipo     = '';    // Tipo activo en los filtros (ej. 'fire', 'water')
let filtroGen      = '';    // Generación activa en los filtros (ej. '1', '2')


// ============================================================
// SECCIÓN 4: REFERENCIAS AL HTML
// ============================================================
// document.getElementById('id') busca y devuelve el elemento
// del HTML que tiene ese id. Lo guardamos en variables para
// poder usarlo después sin tener que buscarlo de nuevo.

// — Tabs y paneles
const tabs   = document.querySelectorAll('.tab-button');   // Todos los botones de pestaña
const panels = document.querySelectorAll('.tab-panel');    // Todos los paneles de pestaña

// — Tarjeta de Pokémon (resultado de búsqueda)
const searchForm     = document.getElementById('search-form');
const searchInput    = document.getElementById('search-input');
const pokemonCard    = document.getElementById('pokemon-card');
const pokemonImagen  = document.getElementById('pokemon-image');
const pokemonNombre  = document.getElementById('pokemon-name');
const pokemonNumero  = document.getElementById('pokemon-id');
const pokemonTipos   = document.getElementById('pokemon-types');
const pokemonAltura  = document.getElementById('pokemon-height');
const pokemonPeso    = document.getElementById('pokemon-weight');
const pokemonHabils  = document.getElementById('pokemon-abilities');
const btnAgregarEquipo = document.getElementById('add-team-button');

// — Catálogo y sus filtros
const catalogoLista    = document.getElementById('catalogue-list');
const btnPrev          = document.getElementById('catalogue-prev');
const btnNext          = document.getElementById('catalogue-next');
const filtroTipoSelect = document.getElementById('filter-type');
const filtroGenSelect  = document.getElementById('filter-gen');
const paginaInfo       = document.getElementById('page-info');

// — Equipo
const equipoLista       = document.getElementById('team-list');
const mensajeUsuario    = document.getElementById('user-message');
const teamFilterType    = document.getElementById('team-filter-type');
const teamFilterGen     = document.getElementById('team-filter-gen');

// — Movimientos
const moveSearchForm  = document.getElementById('move-search-form');
const moveSearchInput = document.getElementById('move-search-input');
const movesList       = document.getElementById('moves-list');

// — Ítems
const itemForm   = document.getElementById('item-form');
const itemInput  = document.getElementById('item-input');
const itemResult = document.getElementById('item-result');

// — Header
const themeToggle  = document.getElementById('theme-toggle');
const logoutButton = document.getElementById('logout-button');
const headerUser   = document.getElementById('header-user');


function iniciarSesionUsuario() {
  if (!NOMBRE_USUARIO) {
    window.location.href = 'index.html'; // Redirige al login
    return;
  }
  // Mostramos el nombre del usuario donde corresponda
  if (mensajeUsuario) mensajeUsuario.textContent = `Hola, ${NOMBRE_USUARIO} 👋`;
  if (headerUser)     headerUser.textContent = NOMBRE_USUARIO;
}

function cerrarSesion() {
  localStorage.removeItem('pokemonUser');
  window.location.href = 'index.html';
}


function aplicarTema() {
  const esDark = localStorage.getItem('darkMode') === 'true';
  document.body.classList.toggle('dark-mode', esDark);
  if (themeToggle) themeToggle.textContent = esDark ? '☀️ Claro' : '🌙 Oscuro';
}

// Alterna entre modo oscuro y claro, y guarda la preferencia.
// document.body.classList.toggle() agrega la clase si no existe, y la quita si existe.
function alternarTema() {
  const esDark = document.body.classList.toggle('dark-mode');
  localStorage.setItem('darkMode', String(esDark));
  themeToggle.textContent = esDark ? '☀️ Claro' : '🌙 Oscuro';
}


function cargarEquipo() {
  try {
    equipo = JSON.parse(localStorage.getItem(CLAVE_EQUIPO)) || [];
  } catch {
    equipo = []; // Si hay un error, empezamos con equipo vacío
  }
  renderizarEquipo();
}

function guardarEquipo() {
  localStorage.setItem(CLAVE_EQUIPO, JSON.stringify(equipo));
}

function renderizarEquipo(lista = equipo) {
  if (!equipoLista) return;
  equipoLista.innerHTML = ''; // Limpia la lista antes de volver a dibujarla

  // Si el equipo (o la lista filtrada) está vacío, mostramos un mensaje
  if (lista.length === 0) {
    const li = document.createElement('li');
    li.className = 'team-empty';
    li.textContent = equipo.length === 0
      ? 'Tu equipo está vacío. Busca un Pokémon y agrégalo.'
      : 'Ningún Pokémon coincide con los filtros.';
    equipoLista.appendChild(li);
    return;
  }

  // Recorremos cada Pokémon del equipo y creamos un elemento de lista
  lista.forEach((pokemon, index) => {
    const li = document.createElement('li');
    li.className = 'team-item';

    // Construimos el HTML de las etiquetas de tipo con sus colores
    const tiposHTML = pokemon.tipos
      .map(t => `<span class="tipo-badge" style="background:${TIPO_COLORES[t] || '#888'}">${t}</span>`)
      .join('');

    // innerHTML asigna HTML directamente al elemento
    li.innerHTML = `
      <img src="${pokemon.imagen}" alt="${pokemon.nombre}" class="team-item-image" loading="lazy" />
      <div class="team-item-info">
        <span class="team-item-name">${pokemon.nombre}</span>
        <span class="team-item-id">#${String(pokemon.id).padStart(3, '0')}</span>
        <div class="team-item-types">${tiposHTML}</div>
      </div>
      <button type="button" class="team-remove-button" aria-label="Quitar">✕</button>
    `;

    // Buscamos el índice real del Pokémon en el equipo original (no en la lista filtrada)
    const indexReal = equipo.findIndex(p => p.id === pokemon.id);

    // Evento del botón "quitar": elimina el Pokémon del arreglo y actualiza
    li.querySelector('.team-remove-button').addEventListener('click', () => {
      equipo.splice(indexReal, 1); // splice() elimina 1 elemento en la posición indexReal
      guardarEquipo();
      renderizarEquipo(); // Re-renderizamos el equipo completo (sin filtros)
    });

    equipoLista.appendChild(li);
  });
}

// Agrega el Pokémon que se está mostrando actualmente al equipo.
function agregarAlEquipo() {
  if (!pokemonActual) {
    alert('Primero busca un Pokémon para poder guardarlo.');
    return;
  }
  if (equipo.length >= 6) {
    alert('Tu equipo ya tiene 6 Pokémon (el máximo).');
    return;
  }
  // .some() devuelve true si algún elemento del arreglo cumple la condición
  if (equipo.some(p => p.id === pokemonActual.id)) {
    alert('Este Pokémon ya está en tu equipo.');
    return;
  }
  equipo.push(pokemonActual); // push() agrega un elemento al final del arreglo
  guardarEquipo();
  renderizarEquipo();

  // Pequeña animación de confirmación en el botón
  btnAgregarEquipo.textContent = '✓ Agregado';
  setTimeout(() => { btnAgregarEquipo.textContent = 'Agregar al equipo'; }, 1500);
}

// Aplica los filtros de tipo y generación al equipo.
function aplicarFiltrosEquipo() {
  const tipo = teamFilterType?.value || '';
  const gen  = teamFilterGen?.value  || '';

  let resultado = [...equipo]; // Copiamos el arreglo para no modificar el original

  // Filtramos por tipo si hay uno seleccionado
  if (tipo) {
    resultado = resultado.filter(p => p.tipos.includes(tipo));
  }

  // Filtramos por generación si hay una seleccionada
  if (gen && GENERACIONES[gen]) {
    const { inicio, fin } = GENERACIONES[gen];
    resultado = resultado.filter(p => p.id >= inicio && p.id <= fin);
  }

  renderizarEquipo(resultado);
}


// ============================================================
// SECCIÓN 8: BÚSQUEDA DE POKÉMON
// ============================================================

// Crea una etiqueta de tipo con su color correspondiente.
function crearEtiquetaTipo(tipo) {
  const span = document.createElement('span');
  span.className = 'tag';
  span.textContent = tipo;
  span.style.background = TIPO_COLORES[tipo] || '#888';
  span.style.color = '#fff';
  return span;
}

// Actualiza la tarjeta de búsqueda con los datos de un Pokémon.
function mostrarTarjetaPokemon(pokemon) {
  pokemonActual = pokemon; // Guardamos el Pokémon actual para usarlo al agregar al equipo

  pokemonImagen.src  = pokemon.imagen;
  pokemonImagen.alt  = pokemon.nombre;
  pokemonNombre.textContent = pokemon.nombre;
  pokemonNumero.textContent = `#${String(pokemon.id).padStart(3, '0')}`;
  pokemonAltura.textContent = `${(pokemon.altura / 10).toFixed(1)} m`;
  pokemonPeso.textContent   = `${(pokemon.peso   / 10).toFixed(1)} kg`;
  pokemonHabils.textContent = pokemon.habilidades.join(', ');

  pokemonTipos.innerHTML = ''; // Limpiamos los tipos anteriores
  pokemon.tipos.forEach(tipo => {
    pokemonTipos.appendChild(crearEtiquetaTipo(tipo));
  });

  pokemonCard.classList.remove('hidden'); // Hacemos visible la tarjeta
}

// Hace una petición a la PokeAPI y obtiene los datos de un Pokémon.
//
// "async" significa que esta función puede hacer operaciones que toman tiempo.
// "await" significa "espera a que esto termine antes de continuar".
// "fetch()" hace una petición a internet (a la API) y devuelve una respuesta.
// "response.json()" convierte la respuesta en un objeto JavaScript.
async function buscarPokemon(query) {
  const termino = query.trim().toLowerCase();
  if (!termino) return;

  // Mostramos indicador de carga
  pokemonCard.classList.remove('hidden');
  pokemonNombre.textContent = 'Buscando...';
  pokemonImagen.src = '';
  pokemonTipos.innerHTML = '';

  try {
    const respuesta = await fetch(`https://pokeapi.co/api/v2/pokemon/${encodeURIComponent(termino)}`);

    // Si la respuesta no es exitosa (ej. 404), lanzamos un error
    if (!respuesta.ok) throw new Error(`Pokémon "${query}" no encontrado. Revisa el nombre o ID.`);

    const datos = await respuesta.json();

    // Creamos nuestro propio objeto con solo los datos que necesitamos
    const pokemon = {
      id:          datos.id,
      nombre:      datos.name.charAt(0).toUpperCase() + datos.name.slice(1),
      imagen:      datos.sprites.other['official-artwork'].front_default
                     || datos.sprites.front_default,
      tipos:       datos.types.map(t => t.type.name),
      altura:      datos.height,
      peso:        datos.weight,
      habilidades: datos.abilities.map(a => a.ability.name),
    };

    mostrarTarjetaPokemon(pokemon);

  } catch (error) {
    // Si algo falla, mostramos el mensaje de error
    pokemonNombre.textContent = '⚠ ' + (error.message || 'Error al buscar.');
    pokemonNumero.textContent  = '';
    pokemonAltura.textContent  = '';
    pokemonPeso.textContent    = '';
    pokemonHabils.textContent  = '';
    pokemonTipos.innerHTML = '';
    pokemonImagen.src = '';
  }
}


function obtenerIdDeUrl(url) {
  const partes = url.split('/').filter(p => p !== ''); // filter elimina los vacíos
  return parseInt(partes[partes.length - 1]);          // tomamos el último segmento
}

function urlSprite(id) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;
}

// Dibuja los Pokémon del catálogo en pantalla.
// Recibe un arreglo de objetos con { name, url }.
function renderizarCatalogo(lista) {
  catalogoLista.innerHTML = '';

  if (!lista || lista.length === 0) {
    catalogoLista.innerHTML = '<p class="cat-empty">No se encontraron Pokémon con esos filtros.</p>';
    return;
  }

  lista.forEach(item => {
    const id     = obtenerIdDeUrl(item.url);
    const nombre = item.name.charAt(0).toUpperCase() + item.name.slice(1);
    const sprite = urlSprite(id);

    const div = document.createElement('div');
    div.className = 'catalogue-item';
    div.innerHTML = `
      <img src="${sprite}" alt="${nombre}" loading="lazy" />
      <span class="catalogue-item-num">#${String(id).padStart(3, '0')}</span>
      <span class="catalogue-item-name">${nombre}</span>
    `;

    // Al hacer clic en un Pokémon del catálogo, lo buscamos y mostramos arriba
    div.addEventListener('click', () => {
      buscarPokemon(nombre);
      // Desplazamos la vista hasta la tarjeta del Pokémon
      pokemonCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });

    catalogoLista.appendChild(div);
  });
}

// Actualiza el texto de la paginación.
function actualizarPaginaInfo() {
  if (!paginaInfo) return;
  const pagina = Math.floor(offsetCatalogo / LIMITE) + 1;
  paginaInfo.textContent = `Página ${pagina}`;
}

// Carga el catálogo sin filtros, desde una posición (offset) dada.
async function cargarCatalogo(offset = 0) {
  catalogoLista.innerHTML = '<p class="loading-msg">Cargando Pokémon...</p>';
  filtroTipo = '';
  filtroGen  = '';
  if (filtroTipoSelect) filtroTipoSelect.value = '';
  if (filtroGenSelect)  filtroGenSelect.value  = '';

  try {
    const res  = await fetch(`https://pokeapi.co/api/v2/pokemon?offset=${offset}&limit=${LIMITE}`);
    if (!res.ok) throw new Error('Error cargando el catálogo.');
    const data = await res.json();
    offsetCatalogo = offset;
    actualizarPaginaInfo();
    renderizarCatalogo(data.results);
  } catch (err) {
    catalogoLista.innerHTML = `<p class="cat-empty">${err.message}</p>`;
  }
}

// Filtra el catálogo por TIPO.
// Usa el endpoint /type/{nombre} de la API, que devuelve todos los Pokémon de ese tipo.
async function filtrarPorTipo(tipo) {
  if (!tipo) { cargarCatalogo(0); return; }

  filtroTipo = tipo;
  filtroGen  = '';
  if (filtroGenSelect) filtroGenSelect.value = '';
  if (paginaInfo) paginaInfo.textContent = `Tipo: ${tipo}`;
  catalogoLista.innerHTML = '<p class="loading-msg">Filtrando por tipo...</p>';

  try {
    const res  = await fetch(`https://pokeapi.co/api/v2/type/${tipo}`);
    if (!res.ok) throw new Error('Tipo no encontrado.');
    const data = await res.json();

    // data.pokemon es un arreglo de { pokemon: { name, url }, slot }
    // Tomamos los primeros LIMITE y extraemos solo el objeto { name, url }
    const lista = data.pokemon.slice(0, LIMITE).map(p => p.pokemon);
    renderizarCatalogo(lista);
  } catch (err) {
    catalogoLista.innerHTML = `<p class="cat-empty">${err.message}</p>`;
  }
}

// Filtra el catálogo por GENERACIÓN.
// Usa el offset y el limit de la generación seleccionada.
async function filtrarPorGeneracion(gen) {
  if (!gen) { cargarCatalogo(0); return; }

  filtroGen  = gen;
  filtroTipo = '';
  if (filtroTipoSelect) filtroTipoSelect.value = '';

  const generacion = GENERACIONES[gen];
  if (!generacion) return;

  if (paginaInfo) paginaInfo.textContent = generacion.nombre;
  catalogoLista.innerHTML = '<p class="loading-msg">Filtrando por generación...</p>';

  try {
    const limit = Math.min(generacion.limit, LIMITE);
    const res   = await fetch(`https://pokeapi.co/api/v2/pokemon?offset=${generacion.offset}&limit=${limit}`);
    if (!res.ok) throw new Error('Error cargando la generación.');
    const data  = await res.json();
    offsetCatalogo = generacion.offset;
    renderizarCatalogo(data.results);
  } catch (err) {
    catalogoLista.innerHTML = `<p class="cat-empty">${err.message}</p>`;
  }
}


async function buscarMovimiento(termino) {
  movesList.innerHTML = '';
  if (!termino) return;

  try {
    const res  = await fetch(`https://pokeapi.co/api/v2/move/${encodeURIComponent(termino.toLowerCase())}`);
    if (!res.ok) throw new Error('Movimiento no encontrado. Escribe el nombre en inglés (ej. "tackle").');
    const data = await res.json();

    const card = document.createElement('div');
    card.className = 'move-card';
    card.innerHTML = `
      <strong>${data.name}</strong>
      <div class="move-stats">
        <span>PP: <b>${data.pp ?? '—'}</b></span>
        <span>Poder: <b>${data.power ?? '—'}</b></span>
        <span>Precisión: <b>${data.accuracy ?? '—'}</b></span>
      </div>
    `;
    movesList.appendChild(card);
  } catch (err) {
    movesList.innerHTML = `<p class="cat-empty">${err.message}</p>`;
  }
}


async function buscarItem(termino) {
  itemResult.innerHTML = '';
  if (!termino) return;

  try {
    const res  = await fetch(`https://pokeapi.co/api/v2/item/${encodeURIComponent(termino.toLowerCase())}`);
    if (!res.ok) throw new Error('Ítem no encontrado. Escribe el nombre en inglés (ej. "potion").');
    const data = await res.json();

    // Buscamos la descripción en español; si no existe, usamos la primera disponible
    const descripcion =
      data.effect_entries.find(e => e.language.name === 'es')?.short_effect ||
      data.effect_entries[0]?.short_effect ||
      'Sin descripción disponible.';

    const sprite = data.sprites?.default
      ? `<img src="${data.sprites.default}" alt="${data.name}" class="item-sprite" />`
      : '';

    itemResult.innerHTML = `
      <div class="item-result-card">
        ${sprite}
        <div>
          <strong>${data.name}</strong>
          <p>${descripcion}</p>
        </div>
      </div>
    `;
  } catch (err) {
    itemResult.innerHTML = `<p class="cat-empty">${err.message}</p>`;
  }
}


function configurarTabs() {
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(btn     => btn.classList.remove('active'));
      panels.forEach(panel => panel.classList.remove('active'));

      tab.classList.add('active');

      // dataset.tab lee el atributo data-tab del HTML
      const panelId = `tab-${tab.dataset.tab}`;
      document.getElementById(panelId)?.classList.add('active');
    });
  });
}


function configurarEventos() {

  // Búsqueda de Pokémon
  searchForm?.addEventListener('submit', e => {
    e.preventDefault(); // Evita que el formulario recargue la página
    buscarPokemon(searchInput.value);
  });

  // Agregar Pokémon al equipo
  btnAgregarEquipo?.addEventListener('click', agregarAlEquipo);

  // Paginación del catálogo
  btnPrev?.addEventListener('click', () => {
    const nuevoOffset = Math.max(0, offsetCatalogo - LIMITE);
    cargarCatalogo(nuevoOffset);
  });

  btnNext?.addEventListener('click', () => {
    cargarCatalogo(offsetCatalogo + LIMITE);
  });

  // Filtros del catálogo
  filtroTipoSelect?.addEventListener('change', e => filtrarPorTipo(e.target.value));
  filtroGenSelect?.addEventListener('change',  e => filtrarPorGeneracion(e.target.value));

  // Filtros del equipo
  teamFilterType?.addEventListener('change', aplicarFiltrosEquipo);
  teamFilterGen?.addEventListener('change',  aplicarFiltrosEquipo);

  // Búsqueda de movimientos
  moveSearchForm?.addEventListener('submit', e => {
    e.preventDefault();
    buscarMovimiento(moveSearchInput.value.trim());
  });

  // Búsqueda de ítems
  itemForm?.addEventListener('submit', e => {
    e.preventDefault();
    buscarItem(itemInput.value.trim());
  });

  // Tema oscuro / claro
  themeToggle?.addEventListener('click', alternarTema);

  // Cerrar sesión
  logoutButton?.addEventListener('click', cerrarSesion);
}


function init() {
  iniciarSesionUsuario(); 
  aplicarTema();         
  cargarEquipo();          
  configurarTabs();      
  configurarEventos();     
  cargarCatalogo(0);       
}

init();
